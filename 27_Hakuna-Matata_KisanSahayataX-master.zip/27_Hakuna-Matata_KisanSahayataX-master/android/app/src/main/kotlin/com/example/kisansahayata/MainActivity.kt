package com.example.kisansahayata

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
