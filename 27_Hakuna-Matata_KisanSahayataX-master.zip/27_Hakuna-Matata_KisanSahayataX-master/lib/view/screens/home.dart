import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedButtonIndex = -1; // To keep track of the selected button

  List<Widget> _buildSmallContainers(int count) {
    return List.generate(count, (index) {
      return Container(
        width: 50,
        height: 50,
        margin: EdgeInsets.all(5),
        color: Colors.blue,
      );
    });
  }

  @override
  List list = [Color(0xff131313), Color(0xff313131)];
  List buttons = [
    "Seeds",
    "Fertilizers",
    "Pesticides",
    "Tools",
    "More",
    "More"
  ];
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff131313),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Location',
                  style: TextStyle(fontSize: 14),
                ),
                Icon(Icons.arrow_drop_down),
                Text(
                  'Aurangabad Maharashtra',
                  style: TextStyle(fontSize: 18),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {
              // Handle profile icon tap
            },
            icon: Icon(Icons.person),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.35,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [Color(0xff131313), Color(0xff313131)],
                  begin: Alignment.bottomRight,
                  end: Alignment.topLeft),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Center(
              child: CarouselSlider(
                options: CarouselOptions(
                  height: MediaQuery.of(context).size.height * 0.15,
                  viewportFraction: 1.0,
                  enableInfiniteScroll: true,
                  autoPlay: true,
                ),
                items: List.generate(
                  5,
                  (index) => Container(
                    //margin: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      //color: Colors.blue,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(child: Image.asset('assets/banner.png')),
                  ),
                ),
              ),
            ),
          ),
          Container(
            //color: Colors.amberAccent,
            // margin: EdgeInsets.only(top: 20),
            //padding: EdgeInsets.only(top: 20),
            height: MediaQuery.of(context).size.height * 0.532,
            child: Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height * 0.07,
                  //padding: EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(
                      //color: Colors.white,
                      //borderRadius: BorderRadius.circular(20),
                      ),
                  child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: List.generate(5, (index) {
                          return Row(
                            children: [
                              TextButton(
                                onPressed: () {
                                  setState(() {
                                    selectedButtonIndex = index;
                                  });
                                },
                                child: Text(
                                  buttons[index],
                                  style: TextStyle(
                                    color: selectedButtonIndex == index
                                        ? Colors.blue
                                        : Colors.black,
                                  ),
                                ),
                              ),
                              //SizedBox(width: 10), // Add space between buttons
                            ],
                          );
                        }),
                      )),
                ),
                if (selectedButtonIndex != -1)
                  Expanded(
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, // Number of columns
                        crossAxisSpacing:
                            5, // Horizontal spacing between containers
                        mainAxisSpacing:
                            5, // Vertical spacing between containers
                      ),
                      itemCount: selectedButtonIndex + 4,
                      itemBuilder: (context, index) {
                        return Container(
                          width: 200,
                          height: 200,
                          child: Image.asset("assets/coriander.png"),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
