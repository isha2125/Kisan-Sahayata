import 'package:flutter/material.dart';
import 'package:kisansahayata/controller/authservice.dart';

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset("assets/img1.png"),
          ElevatedButton.icon(
            onPressed: () {
              AuthService().signInwithGoogle();
            },
            icon: Icon(Icons.abc_rounded),
            label: Text("sign in"),
          ),
        ],
      ),
    );
  }
}
