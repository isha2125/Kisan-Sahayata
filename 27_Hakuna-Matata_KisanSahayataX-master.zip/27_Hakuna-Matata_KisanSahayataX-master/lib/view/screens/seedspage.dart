import 'package:flutter/material.dart';

class Seed extends StatefulWidget {
  @override
  _SeedState createState() => _SeedState();
}

class _SeedState extends State<Seed> {
  double _quantity = 0.5;

  void _incrementQuantity() {
    setState(() {
      _quantity += 0.5;
      if (_quantity > 0.5) {
        _quantity = 0.5;
      }
    });
  }

  void _decrementQuantity() {
    setState(() {
      _quantity -= 0.5;
      if (_quantity < 0.5) {
        _quantity = 0.5;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Page with Quantity Selection',
      home: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              // Top section
              Container(
                height: 200,
                color: Colors.white,
                child: Stack(
                  children: [
                    // Square image
                    Image.asset(
                      'assets/bg.png',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: double.infinity,
                    ),
                    // Bottom right image
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Image.asset(
                        'assets/bg.png',
                        width: 100,
                        height: 100,
                      ),
                    ),
                  ],
                ),
              ),
              // Bottom section
              Container(
                height: 200,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(20)),
                ),
                child: Column(
                  children: [
                    // Title
                    Text(
                      'Seed',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    // Spacer
                    SizedBox(height: 20),
                    // Quantity selection
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Quantity text
                          Text(
                            'Quantity (Kg):',
                            style: TextStyle(color: Colors.white),
                          ),
                          // Counter
                          IconButton(
                            icon: Icon(Icons.add),
                            color: Colors.white,
                            onPressed: _incrementQuantity,
                          ),
                          Text(
                            '$_quantity',
                            style: TextStyle(color: Colors.white),
                          ),
                          // Plus button

                          // Minus button
                          IconButton(
                            icon: Icon(Icons.remove),
                            color: Colors.white,
                            onPressed: _decrementQuantity,
                          ),
                        ],
                      ),
                    ),
                    // Spacer
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
