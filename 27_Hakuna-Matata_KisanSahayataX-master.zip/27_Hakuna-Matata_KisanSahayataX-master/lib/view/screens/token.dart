import 'package:flutter/material.dart';

void main() {
  runApp(TokensApp());
}

class TokensApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tokens Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TokensPage(),
    );
  }
}

class TokensPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tokens'),
      ),
      body: TokenGrid(),
    );
  }
}

class TokenGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Container(
                    color: Colors.green,
                    child: Center(
                      child: Text('Container 1'),
                    ),
                  ),
                ),
                SizedBox(width: 16.0),
                Expanded(
                  child: Container(
                    color: Colors.blue,
                    child: Center(
                      child: Text('Container 2'),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16.0),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Container(
                    color: Colors.orange,
                    child: Center(
                      child: Text('Container 3'),
                    ),
                  ),
                ),
                SizedBox(width: 16.0),
                Expanded(
                  child: Container(
                    color: Colors.purple,
                    child: Center(
                      child: Text('Container 4'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
